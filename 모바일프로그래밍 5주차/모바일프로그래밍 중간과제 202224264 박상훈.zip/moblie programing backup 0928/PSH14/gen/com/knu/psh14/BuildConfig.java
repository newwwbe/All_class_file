/** Automatically generated file. DO NOT MODIFY */
package com.knu.psh14;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}