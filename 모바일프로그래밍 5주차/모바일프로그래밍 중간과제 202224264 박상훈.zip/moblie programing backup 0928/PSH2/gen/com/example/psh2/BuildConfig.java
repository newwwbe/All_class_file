/** Automatically generated file. DO NOT MODIFY */
package com.example.psh2;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}