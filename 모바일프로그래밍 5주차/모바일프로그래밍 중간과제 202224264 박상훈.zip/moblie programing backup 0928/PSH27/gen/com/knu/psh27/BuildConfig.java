/** Automatically generated file. DO NOT MODIFY */
package com.knu.psh27;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}