package com.knu.psh28;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.widget.EditText;

public class PSH28 extends Activity {
	EditText a_E;	//��ü��������

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		a_E = (EditText) findViewById(R.id.a_edt);
	}

}
